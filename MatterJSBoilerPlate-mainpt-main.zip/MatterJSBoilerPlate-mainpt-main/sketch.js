const Engine = Matter.Engine;
const World = Matter.World;
const Bodies = Matter.Bodies;

let engine;
let world;

var options;

var ball, square, rectangle;
var ground;
var left;
var right;
var top_wall;

function setup() {
  createCanvas(710,400);
  engine = Engine.create();
  world = engine.world;
  options = {restituition:0.95};
  
  ball = Bodies.circle(50, 354, 20, options);

  World.add(world, ball);
  
  ground = new Ground(350,390,700,20);
  right = new Ground(700,200,20,400);
  left = new Ground(10,200,20,400);
  top_wall = new Ground(350,10,700,20);

  a1 = new Ground(590,360,10, 40);
  aa1 = new Ground(540,360,10,40);

  rectMode(CENTER);
  ellipseMode(RADIUS);

  btn1 = createImg("up.png");
  btn1.position(30, 30);
  btn1.size(50, 50);
  btn1.mouseClicked(throwBall);
}

function draw() 
{
  background(100);

  ellipse(ball.position.x, ball.position.y, 20);

  ground.show();
  top_wall.show();
  left.show();
  right.show();
  a1.show();
  aa1.show();
  Engine.update(engine);
  Matter.Body.applyForce(ball, {y:0,x:0}, {x:0, y:0});
}

function throwBall(){
  Matter.Body.applyForce(ball, {y:0,x:0}, {x:0.0458, y:-0.05});
}